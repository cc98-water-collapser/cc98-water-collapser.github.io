"use strict";
(() => {
  // src/common/water-lexicon.ts
  var DEFAULT_WATER_WORDS = [
    // 拼音缩写 / 英文简写
    "bd",
    "bdbd",
    "dd",
    "dddd",
    "up",
    "mark",
    "tql",
    "xswl",
    "hhh",
    "hhhh",
    "2333",
    "666",
    // 顶帖
    "\u9876",
    "\u9876\u9876",
    "\u9876\u4E00\u4E0B",
    "\u5E2E\u9876",
    "\u5E2E\u9876\u4E00\u4E0B",
    "\u4EBA\u5DE5\u7F6E\u9876",
    "\u81EA\u9876",
    "\u9876\u8D77\u6765",
    // 占位 / 打卡
    "\u6253\u5361",
    "\u524D\u6392",
    "\u6C99\u53D1",
    "\u677F\u51F3",
    "\u5730\u677F",
    "\u8DEF\u8FC7",
    "\u6C34",
    "\u6C34\u4E00\u8D34",
    "\u6C34\u8D34",
    "\u63D2\u773C",
    "\u773C",
    "\u7559\u540D",
    "\u706B\u94B3\u5218\u660E",
    // 无信息量的社交应答
    "\u6536\u85CF\u4E86",
    "\u5B66\u4E60\u4E86",
    "\u5B66\u5230\u4E86",
    "\u8C22\u8C22\u5206\u4EAB",
    "\u611F\u8C22\u5206\u4EAB",
    "\u8C22\u8C22",
    "\u591A\u8C22",
    "\u652F\u6301",
    "\u652F\u6301\u4E00\u4E0B",
    "\u540C\u95EE",
    "\u8E72",
    "\u8E72\u4E00\u4E2A",
    "\u597D",
    "\u597D\u7684",
    "\u5F88\u597D",
    "\u4E0D\u9519",
    "\u606D\u559C",
    "\u7FA1\u6155",
    "\u7EDD\u4E86",
    "\u6CEA\u76EE",
    "\u597D\u8036",
    "\u6536\u5230",
    "\u5DF2\u9605",
    "\u524D\u6392\u56F4\u89C2"
  ];
  var DEFAULT_WHITELIST_SETTINGS = Object.freeze({
    originalPoster: true,
    moderators: true,
    mentions: true,
    quotes: true
  });
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: DEFAULT_WATER_WORDS,
    whitelist: DEFAULT_WHITELIST_SETTINGS,
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  });

  // src/common/storage.ts
  var SETTINGS_KEY = "settings";
  var MAX_WATER_WORDS_JSON_BYTES = 3e3;
  var DEFAULT_SETTINGS2 = {
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: [...DEFAULT_WATER_WORDS],
    whitelist: {
      originalPoster: true,
      moderators: true,
      mentions: true,
      quotes: true
    },
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function normalizeWords(value) {
    if (!Array.isArray(value)) {
      return [...DEFAULT_SETTINGS2.waterWords];
    }
    const encoder = new TextEncoder();
    const seen = /* @__PURE__ */ new Set();
    const words = [];
    let usedBytes = 2;
    for (const entry of value) {
      if (typeof entry !== "string") {
        continue;
      }
      const word = entry.trim().slice(0, 64);
      if (!word || seen.has(word)) {
        continue;
      }
      const bytes = encoder.encode(JSON.stringify(word)).byteLength + (words.length === 0 ? 0 : 1);
      if (usedBytes + bytes > MAX_WATER_WORDS_JSON_BYTES) {
        break;
      }
      seen.add(word);
      words.push(word);
      usedBytes += bytes;
      if (words.length >= 500) {
        break;
      }
    }
    return words;
  }
  function mergeSettings(value) {
    if (!isRecord(value)) {
      return structuredClone(DEFAULT_SETTINGS2);
    }
    const whitelist = isRecord(value.whitelist) ? value.whitelist : {};
    const sensitivity2 = value.sensitivity;
    const collapseMode2 = value.collapseMode;
    return {
      enabled: typeof value.enabled === "boolean" ? value.enabled : DEFAULT_SETTINGS2.enabled,
      isCollapsed: typeof value.isCollapsed === "boolean" ? value.isCollapsed : DEFAULT_SETTINGS2.isCollapsed,
      collapseMode: collapseMode2 === "placeholder" || collapseMode2 === "hidden" ? collapseMode2 : DEFAULT_SETTINGS2.collapseMode,
      sensitivity: sensitivity2 === "strict" || sensitivity2 === "standard" || sensitivity2 === "loose" ? sensitivity2 : DEFAULT_SETTINGS2.sensitivity,
      waterWords: normalizeWords(value.waterWords),
      whitelist: {
        originalPoster: typeof whitelist.originalPoster === "boolean" ? whitelist.originalPoster : DEFAULT_SETTINGS2.whitelist.originalPoster,
        moderators: typeof whitelist.moderators === "boolean" ? whitelist.moderators : DEFAULT_SETTINGS2.whitelist.moderators,
        mentions: typeof whitelist.mentions === "boolean" ? whitelist.mentions : DEFAULT_SETTINGS2.whitelist.mentions,
        quotes: typeof whitelist.quotes === "boolean" ? whitelist.quotes : DEFAULT_SETTINGS2.whitelist.quotes
      },
      collapsePureMedia: typeof value.collapsePureMedia === "boolean" ? value.collapsePureMedia : DEFAULT_SETTINGS2.collapsePureMedia,
      collapseDuplicates: typeof value.collapseDuplicates === "boolean" ? value.collapseDuplicates : DEFAULT_SETTINGS2.collapseDuplicates,
      shortcutEnabled: typeof value.shortcutEnabled === "boolean" ? value.shortcutEnabled : DEFAULT_SETTINGS2.shortcutEnabled
    };
  }
  function readArea(area, key) {
    return new Promise((resolve, reject) => {
      area.get(key, (items) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(items[key]);
      });
    });
  }
  function writeArea(area, values) {
    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }
  async function getSettings() {
    const stored = await readArea(chrome.storage.sync, SETTINGS_KEY);
    const merged = mergeSettings(stored);
    if (isRecord(stored) && ("collapseCustomComments" in stored || "customMatchMode" in stored || "customCommentRules" in stored)) {
      await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: merged });
    }
    return merged;
  }
  async function saveSettings(settings2) {
    await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: mergeSettings(settings2) });
  }
  async function resetSettings() {
    const defaults = structuredClone(DEFAULT_SETTINGS2);
    await saveSettings(defaults);
    return defaults;
  }
  function watchSettings(listener) {
    const handleChange = (changes, areaName) => {
      if (areaName !== "sync" || !changes[SETTINGS_KEY]) {
        return;
      }
      listener(mergeSettings(changes[SETTINGS_KEY].newValue));
    };
    chrome.storage.onChanged.addListener(handleChange);
    return () => chrome.storage.onChanged.removeListener(handleChange);
  }

  // src/options/options.ts
  function requiredElement(selector) {
    const element = document.querySelector(selector);
    if (!element) {
      throw new Error(`\u7F3A\u5C11\u754C\u9762\u5143\u7D20\uFF1A${selector}`);
    }
    return element;
  }
  var form = requiredElement("#settings-form");
  var enabled = requiredElement("#enabled");
  var collapseMode = requiredElement("#collapse-mode");
  var sensitivity = requiredElement("#sensitivity");
  var collapsePureMedia = requiredElement("#collapse-pure-media");
  var collapseDuplicates = requiredElement("#collapse-duplicates");
  var shortcutEnabled = requiredElement("#shortcut-enabled");
  var whitelistOp = requiredElement("#whitelist-op");
  var whitelistModerator = requiredElement("#whitelist-moderator");
  var whitelistMention = requiredElement("#whitelist-mention");
  var whitelistQuote = requiredElement("#whitelist-quote");
  var waterWords = requiredElement("#water-words");
  var wordCount = requiredElement("#word-count");
  var resetButton = requiredElement("#reset");
  var status = requiredElement("#status");
  var settings = structuredClone(DEFAULT_SETTINGS2);
  var hasUnsavedChanges = false;
  function parseWords(value) {
    return [
      ...new Set(
        value.split(/\r?\n/u).map((word) => word.trim().slice(0, 64)).filter(Boolean)
      )
    ].slice(0, 500);
  }
  function updateWordCount() {
    wordCount.textContent = `${parseWords(waterWords.value).length} \u6761`;
  }
  function render(next) {
    settings = next;
    enabled.checked = next.enabled;
    collapseMode.value = next.collapseMode;
    sensitivity.value = next.sensitivity;
    collapsePureMedia.checked = next.collapsePureMedia;
    collapseDuplicates.checked = next.collapseDuplicates;
    shortcutEnabled.checked = next.shortcutEnabled;
    whitelistOp.checked = next.whitelist.originalPoster;
    whitelistModerator.checked = next.whitelist.moderators;
    whitelistMention.checked = next.whitelist.mentions;
    whitelistQuote.checked = next.whitelist.quotes;
    waterWords.value = next.waterWords.join("\n");
    updateWordCount();
    hasUnsavedChanges = false;
  }
  function setFormDisabled(disabled) {
    Array.from(form.elements).forEach((control) => {
      if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement || control instanceof HTMLTextAreaElement || control instanceof HTMLButtonElement) {
        control.disabled = disabled;
      }
    });
  }
  function readForm(baseSettings) {
    return {
      ...baseSettings,
      enabled: enabled.checked,
      collapseMode: collapseMode.value,
      sensitivity: sensitivity.value,
      waterWords: parseWords(waterWords.value),
      whitelist: {
        originalPoster: whitelistOp.checked,
        moderators: whitelistModerator.checked,
        mentions: whitelistMention.checked,
        quotes: whitelistQuote.checked
      },
      collapsePureMedia: collapsePureMedia.checked,
      collapseDuplicates: collapseDuplicates.checked,
      shortcutEnabled: shortcutEnabled.checked
    };
  }
  render(settings);
  setFormDisabled(true);
  waterWords.addEventListener("input", updateWordCount);
  var markUnsavedChanges = () => {
    hasUnsavedChanges = true;
  };
  form.addEventListener("input", markUnsavedChanges);
  form.addEventListener("change", markUnsavedChanges);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    setFormDisabled(true);
    void getSettings().then((latest) => {
      const next = readForm(latest);
      return saveSettings(next).then(() => next);
    }).then((next) => {
      render(next);
      status.textContent = "\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\uFF0C\u5E76\u4F1A\u540C\u6B65\u5230\u5DF2\u6253\u5F00\u7684 CC98 \u9875\u9762\u3002";
    }).catch((error) => {
      status.textContent = "\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002";
      console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] Options \u4FDD\u5B58\u5931\u8D25\u3002", error);
    }).finally(() => {
      setFormDisabled(false);
    });
  });
  resetButton.addEventListener("click", () => {
    setFormDisabled(true);
    void resetSettings().then((defaults) => {
      render(defaults);
      status.textContent = "\u5DF2\u6062\u590D\u9ED8\u8BA4\u503C\u3002";
    }).catch((error) => {
      status.textContent = "\u6062\u590D\u9ED8\u8BA4\u503C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002";
      console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] Options \u91CD\u7F6E\u5931\u8D25\u3002", error);
    }).finally(() => {
      setFormDisabled(false);
    });
  });
  void getSettings().then((stored) => {
    render(stored);
    watchSettings((next) => {
      settings = next;
      if (hasUnsavedChanges) {
        status.textContent = "\u8BBE\u7F6E\u5DF2\u5728\u5176\u4ED6\u7A97\u53E3\u66F4\u65B0\uFF1B\u5F53\u524D\u672A\u4FDD\u5B58\u7684\u7F16\u8F91\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u786E\u8BA4\u540E\u518D\u4FDD\u5B58\u3002";
        return;
      }
      render(next);
    });
    setFormDisabled(false);
  }).catch((error) => {
    status.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u6269\u5C55\u8BBE\u7F6E\u3002";
    console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] Options \u521D\u59CB\u5316\u5931\u8D25\u3002", error);
  });
})();
