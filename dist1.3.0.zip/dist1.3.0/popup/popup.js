"use strict";
(() => {
  // src/common/water-lexicon.ts
  var DEFAULT_WATER_WORDS = [
    // 拼音缩写 / 英文简写
    "bd",
    "bdbd",
    "dd",
    "dddd",
    "up",
    "mark",
    "tql",
    "xswl",
    "hhh",
    "hhhh",
    "2333",
    "666",
    // 顶帖
    "\u9876",
    "\u9876\u9876",
    "\u9876\u4E00\u4E0B",
    "\u5E2E\u9876",
    "\u5E2E\u9876\u4E00\u4E0B",
    "\u4EBA\u5DE5\u7F6E\u9876",
    "\u81EA\u9876",
    "\u9876\u8D77\u6765",
    // 占位 / 打卡
    "\u6253\u5361",
    "\u524D\u6392",
    "\u6C99\u53D1",
    "\u677F\u51F3",
    "\u5730\u677F",
    "\u8DEF\u8FC7",
    "\u6C34",
    "\u6C34\u4E00\u8D34",
    "\u6C34\u8D34",
    "\u63D2\u773C",
    "\u773C",
    "\u7559\u540D",
    "\u706B\u94B3\u5218\u660E",
    // 无信息量的社交应答
    "\u6536\u85CF\u4E86",
    "\u5B66\u4E60\u4E86",
    "\u5B66\u5230\u4E86",
    "\u8C22\u8C22\u5206\u4EAB",
    "\u611F\u8C22\u5206\u4EAB",
    "\u8C22\u8C22",
    "\u591A\u8C22",
    "\u652F\u6301",
    "\u652F\u6301\u4E00\u4E0B",
    "\u540C\u95EE",
    "\u8E72",
    "\u8E72\u4E00\u4E2A",
    "\u597D",
    "\u597D\u7684",
    "\u5F88\u597D",
    "\u4E0D\u9519",
    "\u606D\u559C",
    "\u7FA1\u6155",
    "\u7EDD\u4E86",
    "\u6CEA\u76EE",
    "\u597D\u8036",
    "\u6536\u5230",
    "\u5DF2\u9605",
    "\u524D\u6392\u56F4\u89C2"
  ];
  var DEFAULT_WHITELIST_SETTINGS = Object.freeze({
    originalPoster: true,
    moderators: true,
    mentions: true,
    quotes: true
  });
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: DEFAULT_WATER_WORDS,
    whitelist: DEFAULT_WHITELIST_SETTINGS,
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  });

  // src/common/storage.ts
  var SETTINGS_KEY = "settings";
  var PAGE_STATS_KEY = "latestPageStats";
  var MAX_WATER_WORDS_JSON_BYTES = 3e3;
  var DEFAULT_SETTINGS2 = {
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: [...DEFAULT_WATER_WORDS],
    whitelist: {
      originalPoster: true,
      moderators: true,
      mentions: true,
      quotes: true
    },
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function normalizeWords(value) {
    if (!Array.isArray(value)) {
      return [...DEFAULT_SETTINGS2.waterWords];
    }
    const encoder = new TextEncoder();
    const seen = /* @__PURE__ */ new Set();
    const words = [];
    let usedBytes = 2;
    for (const entry of value) {
      if (typeof entry !== "string") {
        continue;
      }
      const word = entry.trim().slice(0, 64);
      if (!word || seen.has(word)) {
        continue;
      }
      const bytes = encoder.encode(JSON.stringify(word)).byteLength + (words.length === 0 ? 0 : 1);
      if (usedBytes + bytes > MAX_WATER_WORDS_JSON_BYTES) {
        break;
      }
      seen.add(word);
      words.push(word);
      usedBytes += bytes;
      if (words.length >= 500) {
        break;
      }
    }
    return words;
  }
  function mergeSettings(value) {
    if (!isRecord(value)) {
      return structuredClone(DEFAULT_SETTINGS2);
    }
    const whitelist = isRecord(value.whitelist) ? value.whitelist : {};
    const sensitivity = value.sensitivity;
    const collapseMode = value.collapseMode;
    return {
      enabled: typeof value.enabled === "boolean" ? value.enabled : DEFAULT_SETTINGS2.enabled,
      isCollapsed: typeof value.isCollapsed === "boolean" ? value.isCollapsed : DEFAULT_SETTINGS2.isCollapsed,
      collapseMode: collapseMode === "placeholder" || collapseMode === "hidden" ? collapseMode : DEFAULT_SETTINGS2.collapseMode,
      sensitivity: sensitivity === "strict" || sensitivity === "standard" || sensitivity === "loose" ? sensitivity : DEFAULT_SETTINGS2.sensitivity,
      waterWords: normalizeWords(value.waterWords),
      whitelist: {
        originalPoster: typeof whitelist.originalPoster === "boolean" ? whitelist.originalPoster : DEFAULT_SETTINGS2.whitelist.originalPoster,
        moderators: typeof whitelist.moderators === "boolean" ? whitelist.moderators : DEFAULT_SETTINGS2.whitelist.moderators,
        mentions: typeof whitelist.mentions === "boolean" ? whitelist.mentions : DEFAULT_SETTINGS2.whitelist.mentions,
        quotes: typeof whitelist.quotes === "boolean" ? whitelist.quotes : DEFAULT_SETTINGS2.whitelist.quotes
      },
      collapsePureMedia: typeof value.collapsePureMedia === "boolean" ? value.collapsePureMedia : DEFAULT_SETTINGS2.collapsePureMedia,
      collapseDuplicates: typeof value.collapseDuplicates === "boolean" ? value.collapseDuplicates : DEFAULT_SETTINGS2.collapseDuplicates,
      shortcutEnabled: typeof value.shortcutEnabled === "boolean" ? value.shortcutEnabled : DEFAULT_SETTINGS2.shortcutEnabled
    };
  }
  function readArea(area, key) {
    return new Promise((resolve, reject) => {
      area.get(key, (items) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(items[key]);
      });
    });
  }
  function writeArea(area, values) {
    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }
  async function getSettings() {
    const stored = await readArea(chrome.storage.sync, SETTINGS_KEY);
    const merged = mergeSettings(stored);
    if (isRecord(stored) && ("collapseCustomComments" in stored || "customMatchMode" in stored || "customCommentRules" in stored)) {
      await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: merged });
    }
    return merged;
  }
  async function saveSettings(settings2) {
    await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: mergeSettings(settings2) });
  }
  function normalizePageStats(stats) {
    if (!isRecord(stats)) {
      return void 0;
    }
    const pageId = typeof stats.pageId === "string" ? stats.pageId : "";
    if (!pageId) {
      return void 0;
    }
    return {
      pageId,
      detectedCount: Number(stats.detectedCount) || 0,
      waterCount: Number(stats.waterCount) || 0,
      customCount: Number(stats.customCount) || 0,
      duplicateCount: Number(stats.duplicateCount) || 0,
      collapsedCount: Number(stats.collapsedCount) || 0,
      isCollapsed: Boolean(stats.isCollapsed),
      updatedAt: Number(stats.updatedAt) || 0
    };
  }
  async function getLatestPageStats() {
    return normalizePageStats(await readArea(chrome.storage.local, PAGE_STATS_KEY));
  }
  function watchSettings(listener) {
    const handleChange = (changes, areaName) => {
      if (areaName !== "sync" || !changes[SETTINGS_KEY]) {
        return;
      }
      listener(mergeSettings(changes[SETTINGS_KEY].newValue));
    };
    chrome.storage.onChanged.addListener(handleChange);
    return () => chrome.storage.onChanged.removeListener(handleChange);
  }

  // src/common/custom-rules.ts
  var WHITESPACE_PATTERN = new RegExp("\\p{White_Space}+", "gu");
  var MAX_RULES = 100;
  var MAX_RULE_LENGTH = 200;
  function normalizeCustomCommentText(text) {
    return text.normalize("NFKC").replace(WHITESPACE_PATTERN, " ").trim();
  }
  function normalizeCustomCommentRules(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    const seen = /* @__PURE__ */ new Set();
    const rules = [];
    for (const entry of value) {
      if (typeof entry !== "string") {
        continue;
      }
      const rule = normalizeCustomCommentText(entry);
      if (!rule || Array.from(rule).length > MAX_RULE_LENGTH || seen.has(rule)) {
        continue;
      }
      seen.add(rule);
      rules.push(rule);
      if (rules.length >= MAX_RULES) {
        break;
      }
    }
    return rules;
  }

  // src/common/messages.ts
  var APPLY_TRANSIENT_CUSTOM_RULES = "cc98wc:apply-transient-custom-rules";
  var CLEAR_TRANSIENT_CUSTOM_RULES = "cc98wc:clear-transient-custom-rules";
  var EXPAND_ALL_REPLIES = "cc98wc:expand-all-replies";
  var GET_TRANSIENT_CUSTOM_STATE = "cc98wc:get-transient-custom-state";
  var MAX_RAW_INPUT_LENGTH = 20100;
  function isRecord2(value) {
    return typeof value === "object" && value !== null;
  }
  function isContentMessageResponse(value) {
    if (!isRecord2(value) || typeof value.ok !== "boolean") {
      return false;
    }
    if (value.ok) {
      if (value.kind === "action") {
        return typeof value.customCount === "number" && Number.isFinite(value.customCount) && typeof value.collapsedCount === "number" && Number.isFinite(value.collapsedCount);
      }
      return value.kind === "state" && typeof value.rawInput === "string" && value.rawInput.length <= MAX_RAW_INPUT_LENGTH && (value.mode === "exact" || value.mode === "contains");
    }
    return value.error === "disabled" || value.error === "invalid-message" || value.error === "no-topic" || value.error === "no-valid-rules";
  }

  // src/popup/popup.ts
  function requiredElement(selector) {
    const element = document.querySelector(selector);
    if (!element) {
      throw new Error(`\u7F3A\u5C11\u754C\u9762\u5143\u7D20\uFF1A${selector}`);
    }
    return element;
  }
  var enabledInput = requiredElement("#enabled");
  var collapseButton = requiredElement("#collapse");
  var expandButton = requiredElement("#expand");
  var optionsButton = requiredElement("#open-options");
  var customRules = requiredElement("#custom-rules");
  var customMode = requiredElement("#custom-mode");
  var applyCustomButton = requiredElement("#apply-custom");
  var clearCustomButton = requiredElement("#clear-custom");
  var detectedCount = requiredElement("#detected-count");
  var waterCount = requiredElement("#water-count");
  var customCount = requiredElement("#custom-count");
  var duplicateCount = requiredElement("#duplicate-count");
  var collapsedCount = requiredElement("#collapsed-count");
  var freshness = requiredElement("#stats-freshness");
  var status = requiredElement("#status");
  var settings = structuredClone(DEFAULT_SETTINGS2);
  var updateInFlight = false;
  function renderSettings() {
    enabledInput.checked = settings.enabled;
    enabledInput.disabled = updateInFlight;
    collapseButton.disabled = updateInFlight || !settings.enabled || settings.isCollapsed;
    expandButton.disabled = updateInFlight || !settings.enabled;
    customRules.disabled = updateInFlight || !settings.enabled;
    customMode.disabled = updateInFlight || !settings.enabled;
    applyCustomButton.disabled = updateInFlight || !settings.enabled;
    clearCustomButton.disabled = updateInFlight || !settings.enabled;
  }
  function renderStats(stats) {
    if (!stats) {
      detectedCount.textContent = "\u2014";
      waterCount.textContent = "\u2014";
      customCount.textContent = "\u2014";
      duplicateCount.textContent = "\u2014";
      collapsedCount.textContent = "\u2014";
      freshness.textContent = "\u7B49\u5F85\u5E16\u5B50\u9875";
      return;
    }
    detectedCount.textContent = String(stats.detectedCount);
    waterCount.textContent = String(stats.waterCount);
    customCount.textContent = String(stats.customCount);
    duplicateCount.textContent = String(stats.duplicateCount);
    collapsedCount.textContent = String(stats.collapsedCount);
    const seconds = Math.max(0, Math.floor((Date.now() - stats.updatedAt) / 1e3));
    freshness.textContent = seconds < 10 ? "\u521A\u521A\u66F4\u65B0" : `${seconds} \u79D2\u524D\u66F4\u65B0`;
  }
  async function updateSettings(patch, message) {
    if (updateInFlight) {
      return;
    }
    updateInFlight = true;
    const previous = settings;
    settings = { ...settings, ...patch };
    renderSettings();
    try {
      const latest = await getSettings();
      settings = { ...latest, ...patch };
      await saveSettings(settings);
      renderSettings();
      status.textContent = message;
    } catch (error) {
      settings = previous;
      renderSettings();
      status.textContent = "\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002";
      console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] Popup \u4FDD\u5B58\u8BBE\u7F6E\u5931\u8D25\u3002", error);
    } finally {
      updateInFlight = false;
      renderSettings();
    }
  }
  async function sendToActiveContentScript(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (typeof tab?.id !== "number") {
      throw new Error("active-tab-unavailable");
    }
    const response = await chrome.tabs.sendMessage(tab.id, message);
    if (!isContentMessageResponse(response)) {
      throw new Error("invalid-content-response");
    }
    return response;
  }
  function responseErrorMessage(response) {
    if (response.ok) {
      return "";
    }
    switch (response.error) {
      case "disabled":
        return "\u8BF7\u5148\u542F\u7528\u6269\u5C55\u3002";
      case "no-valid-rules":
        return "\u6CA1\u6709\u53EF\u7528\u89C4\u5219\uFF1B\u6BCF\u884C\u6700\u591A 200 \u4E2A\u5B57\u7B26\u3002";
      case "no-topic":
        return "\u5F53\u524D\u9875\u4E0D\u662F\u53EF\u8BC6\u522B\u7684 CC98 \u5E16\u5B50\u9875\u3002";
      default:
        return "\u6D88\u606F\u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u3002";
    }
  }
  async function runTransientAction(action) {
    if (updateInFlight) {
      return;
    }
    updateInFlight = true;
    renderSettings();
    try {
      await action();
    } catch (error) {
      status.textContent = "\u8BF7\u5728\u5DF2\u52A0\u8F7D\u672C\u6269\u5C55\u7684 CC98 \u5E16\u5B50\u9875\u4F7F\u7528\u6B64\u529F\u80FD\u3002";
      console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] \u65E0\u6CD5\u8FDE\u63A5\u5F53\u524D\u5E16\u5B50\u9875\u3002", error);
    } finally {
      updateInFlight = false;
      renderSettings();
    }
  }
  enabledInput.addEventListener("change", () => {
    void updateSettings({ enabled: enabledInput.checked }, enabledInput.checked ? "\u5DF2\u542F\u7528" : "\u5DF2\u505C\u7528");
  });
  collapseButton.addEventListener("click", () => {
    void updateSettings({ isCollapsed: true }, "\u5DF2\u8BF7\u6C42\u6298\u53E0");
  });
  expandButton.addEventListener("click", () => {
    void runTransientAction(async () => {
      const latest = await getSettings();
      settings = { ...latest, isCollapsed: false };
      await saveSettings(settings);
      try {
        await sendToActiveContentScript({ type: EXPAND_ALL_REPLIES });
      } catch {
      }
      status.textContent = "\u5DF2\u5C55\u5F00\u5168\u90E8\u56DE\u590D\u5E76\u6E05\u9664\u672C\u6B21\u89C4\u5219";
    });
  });
  applyCustomButton.addEventListener("click", () => {
    void runTransientAction(async () => {
      const rules = normalizeCustomCommentRules(customRules.value.split(/\r?\n/u));
      if (rules.length === 0) {
        status.textContent = "\u8BF7\u8F93\u5165\u81F3\u5C11\u4E00\u6761\u4E0D\u8D85\u8FC7 200 \u4E2A\u5B57\u7B26\u7684\u89C4\u5219\u3002";
        return;
      }
      const response = await sendToActiveContentScript({
        type: APPLY_TRANSIENT_CUSTOM_RULES,
        rawInput: customRules.value,
        mode: customMode.value
      });
      if (!response.ok) {
        status.textContent = responseErrorMessage(response);
        return;
      }
      if (response.kind !== "action") {
        throw new Error("unexpected-state-response");
      }
      status.textContent = `\u5DF2\u6309\u672C\u6B21\u89C4\u5219\u6298\u53E0\uFF0C\u547D\u4E2D ${response.customCount} \u6761\u3002`;
    });
  });
  clearCustomButton.addEventListener("click", () => {
    void runTransientAction(async () => {
      const response = await sendToActiveContentScript({
        type: CLEAR_TRANSIENT_CUSTOM_RULES
      });
      if (!response.ok) {
        status.textContent = responseErrorMessage(response);
        return;
      }
      if (response.kind !== "action") {
        throw new Error("unexpected-state-response");
      }
      customRules.value = "";
      customMode.value = "exact";
      status.textContent = "\u5DF2\u6E05\u9664\u672C\u6B21\u89C4\u5219\uFF1B\u5176\u4ED6\u6298\u53E0\u8BBE\u7F6E\u4FDD\u6301\u4E0D\u53D8\u3002";
    });
  });
  optionsButton.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  renderSettings();
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes[PAGE_STATS_KEY]) {
      renderStats(normalizePageStats(changes[PAGE_STATS_KEY].newValue));
    }
  });
  async function start() {
    try {
      [settings] = await Promise.all([getSettings(), getLatestPageStats().then(renderStats)]);
      renderSettings();
      watchSettings((next) => {
        settings = next;
        renderSettings();
      });
      try {
        const response = await sendToActiveContentScript({ type: GET_TRANSIENT_CUSTOM_STATE });
        if (response.ok && response.kind === "state") {
          customRules.value = response.rawInput;
          customMode.value = response.mode;
        }
      } catch {
      }
    } catch (error) {
      status.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u6269\u5C55\u8BBE\u7F6E\u3002";
      console.warn("[CC98 \u6C34\u5E16\u6298\u53E0\u5668] Popup \u521D\u59CB\u5316\u5931\u8D25\u3002", error);
    }
  }
  void start();
})();
