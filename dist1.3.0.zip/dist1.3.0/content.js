"use strict";
(() => {
  // src/common/normalize.ts
  var KEYCAP_SEQUENCE_PATTERN = /[#*0-9]\uFE0F?\u20E3/gu;
  var EMOJI_PATTERN = new RegExp("(?:\\p{Extended_Pictographic}|\\p{Emoji_Presentation}|\\p{Regional_Indicator}|\\p{Emoji_Modifier})", "gu");
  var VARIATION_SELECTOR_PATTERN = /[\uFE0E\uFE0F\u{E0100}-\u{E01EF}]/gu;
  var DECORATION_PATTERN = /[\p{White_Space}\p{Punctuation}\p{Symbol}\p{Cf}]/gu;
  var HAN_PATTERN = new RegExp("\\p{Script=Han}", "u");
  var NUMBER_PATTERN = new RegExp("\\p{Number}", "u");
  function normalizeText(text) {
    const withoutEmoji = text.replace(KEYCAP_SEQUENCE_PATTERN, "").replace(EMOJI_PATTERN, "").replace(VARIATION_SELECTOR_PATTERN, "").replace(DECORATION_PATTERN, "");
    return withoutEmoji.normalize("NFKC").toLowerCase().replace(DECORATION_PATTERN, "");
  }
  function codePointLength(text) {
    return Array.from(text).length;
  }
  function containsHanCharacter(text) {
    return HAN_PATTERN.test(text);
  }
  function containsNumber(text) {
    return NUMBER_PATTERN.test(text);
  }
  function isRepeatedCharacter(text, minCount = 3) {
    const characters = Array.from(text);
    if (characters.length < minCount) {
      return false;
    }
    const first = characters[0];
    return first !== void 0 && characters.every((character) => character === first);
  }

  // src/common/water-lexicon.ts
  var DEFAULT_WATER_WORDS = [
    // 拼音缩写 / 英文简写
    "bd",
    "bdbd",
    "dd",
    "dddd",
    "up",
    "mark",
    "tql",
    "xswl",
    "hhh",
    "hhhh",
    "2333",
    "666",
    // 顶帖
    "\u9876",
    "\u9876\u9876",
    "\u9876\u4E00\u4E0B",
    "\u5E2E\u9876",
    "\u5E2E\u9876\u4E00\u4E0B",
    "\u4EBA\u5DE5\u7F6E\u9876",
    "\u81EA\u9876",
    "\u9876\u8D77\u6765",
    // 占位 / 打卡
    "\u6253\u5361",
    "\u524D\u6392",
    "\u6C99\u53D1",
    "\u677F\u51F3",
    "\u5730\u677F",
    "\u8DEF\u8FC7",
    "\u6C34",
    "\u6C34\u4E00\u8D34",
    "\u6C34\u8D34",
    "\u63D2\u773C",
    "\u773C",
    "\u7559\u540D",
    "\u706B\u94B3\u5218\u660E",
    // 无信息量的社交应答
    "\u6536\u85CF\u4E86",
    "\u5B66\u4E60\u4E86",
    "\u5B66\u5230\u4E86",
    "\u8C22\u8C22\u5206\u4EAB",
    "\u611F\u8C22\u5206\u4EAB",
    "\u8C22\u8C22",
    "\u591A\u8C22",
    "\u652F\u6301",
    "\u652F\u6301\u4E00\u4E0B",
    "\u540C\u95EE",
    "\u8E72",
    "\u8E72\u4E00\u4E2A",
    "\u597D",
    "\u597D\u7684",
    "\u5F88\u597D",
    "\u4E0D\u9519",
    "\u606D\u559C",
    "\u7FA1\u6155",
    "\u7EDD\u4E86",
    "\u6CEA\u76EE",
    "\u597D\u8036",
    "\u6536\u5230",
    "\u5DF2\u9605",
    "\u524D\u6392\u56F4\u89C2"
  ];
  var DEFAULT_WHITELIST_SETTINGS = Object.freeze({
    originalPoster: true,
    moderators: true,
    mentions: true,
    quotes: true
  });
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: DEFAULT_WATER_WORDS,
    whitelist: DEFAULT_WHITELIST_SETTINGS,
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  });

  // src/common/detect.ts
  var SENSITIVITY_THRESHOLDS = Object.freeze({
    strict: 1,
    standard: 2,
    loose: 4
  });
  var lexiconCache = /* @__PURE__ */ new WeakMap();
  function isWhitelisted(input, settings2) {
    if (input.hasCode || input.hasLink) {
      return true;
    }
    return input.isOriginalPoster && settings2.whitelist.originalPoster || input.isModerator && settings2.whitelist.moderators || input.hasMention && settings2.whitelist.mentions || input.hasQuote && settings2.whitelist.quotes;
  }
  function createNormalizedLexicon(words) {
    const cached = lexiconCache.get(words);
    if (cached) {
      return cached;
    }
    const normalizedWords = words.map(normalizeText).filter((word) => word.length > 0);
    const result = new Set(normalizedWords);
    lexiconCache.set(words, result);
    return result;
  }
  function containsEmbeddedWaterWord(normalized, waterWords) {
    return [...waterWords].some(
      (word) => word.length >= 2 && normalized !== word && normalized.includes(word)
    );
  }
  function detectWaterReply(input, settings2 = DEFAULT_SETTINGS) {
    const normalized = normalizeText(input.text);
    if (!settings2.enabled) {
      return { isWater: false, reason: "disabled", normalized };
    }
    if (isWhitelisted(input, settings2)) {
      return { isWater: false, reason: "whitelisted", normalized };
    }
    const waterWords = createNormalizedLexicon(settings2.waterWords);
    if (normalized.length > 0 && waterWords.has(normalized)) {
      return {
        isWater: true,
        reason: "exact-water-word",
        normalized,
        matchedWord: normalized
      };
    }
    if (isRepeatedCharacter(normalized)) {
      return { isWater: true, reason: "repeated-character", normalized };
    }
    const threshold = SENSITIVITY_THRESHOLDS[settings2.sensitivity];
    if (normalized.length > 0 && codePointLength(normalized) <= threshold && !containsHanCharacter(normalized) && !containsNumber(normalized) && !containsEmbeddedWaterWord(normalized, waterWords)) {
      return { isWater: true, reason: "short-non-content", normalized };
    }
    if (normalized.length === 0) {
      return {
        isWater: settings2.collapsePureMedia,
        reason: "pure-media",
        normalized
      };
    }
    return { isWater: false, reason: "content", normalized };
  }

  // src/common/classification.ts
  function resolveReplyPriority(input) {
    if (input.protected) {
      return "protected";
    }
    if (input.customMatch) {
      return "custom";
    }
    if (input.waterMatch) {
      return "water";
    }
    return "content";
  }

  // src/common/custom-rules.ts
  var WHITESPACE_PATTERN = new RegExp("\\p{White_Space}+", "gu");
  var MAX_RULES = 100;
  var MAX_RULE_LENGTH = 200;
  function normalizeCustomCommentText(text) {
    return text.normalize("NFKC").replace(WHITESPACE_PATTERN, " ").trim();
  }
  function normalizeCustomCommentRules(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    const seen = /* @__PURE__ */ new Set();
    const rules = [];
    for (const entry of value) {
      if (typeof entry !== "string") {
        continue;
      }
      const rule = normalizeCustomCommentText(entry);
      if (!rule || Array.from(rule).length > MAX_RULE_LENGTH || seen.has(rule)) {
        continue;
      }
      seen.add(rule);
      rules.push(rule);
      if (rules.length >= MAX_RULES) {
        break;
      }
    }
    return rules;
  }
  function matchesCustomComment(text, rules, mode) {
    const normalizedText = normalizeCustomCommentText(text);
    if (!normalizedText || rules.length === 0) {
      return false;
    }
    const normalizedRules = normalizeCustomCommentRules(rules);
    return mode === "contains" ? normalizedRules.some((rule) => normalizedText.includes(rule)) : normalizedRules.includes(normalizedText);
  }

  // src/common/duplicate.ts
  var WHITESPACE_PATTERN2 = new RegExp("\\p{White_Space}+", "gu");
  function normalizeDuplicateText(text) {
    return text.normalize("NFKC").replace(WHITESPACE_PATTERN2, " ").trim();
  }
  function canonicalizeImageSource(source, baseUrl = "https://www.cc98.org/") {
    const trimmed = source.trim();
    if (!trimmed) {
      return null;
    }
    try {
      const url = new URL(trimmed, baseUrl);
      url.hash = "";
      return url.href;
    } catch {
      return null;
    }
  }
  function createDuplicateFingerprint(input) {
    if (input.hasLink || input.hasQuote || input.hasCode || input.hasUnsupportedMedia) {
      return null;
    }
    const text = normalizeDuplicateText(input.text);
    const canonicalImages = input.imageSources.map((source) => canonicalizeImageSource(source));
    if (canonicalImages.some((source) => source === null)) {
      return null;
    }
    const images = canonicalImages;
    if (text && images.length === 0) {
      return `text:${JSON.stringify(text)}`;
    }
    if (!text && images.length > 0) {
      return `images:${JSON.stringify(images)}`;
    }
    return null;
  }
  function findDuplicateFlags(fingerprints) {
    const seen = /* @__PURE__ */ new Set();
    return fingerprints.map((fingerprint) => {
      if (fingerprint === null) {
        return false;
      }
      if (seen.has(fingerprint)) {
        return true;
      }
      seen.add(fingerprint);
      return false;
    });
  }
  function classifyDuplicateFingerprints(fingerprints, enabled, protectedEntries = []) {
    return findDuplicateFlags(fingerprints).map((candidateIsDuplicate, index) => {
      const isDuplicate = candidateIsDuplicate && protectedEntries[index] !== true;
      return {
        isDuplicate,
        shouldCollapse: enabled && isDuplicate
      };
    });
  }

  // src/common/storage.ts
  var SETTINGS_KEY = "settings";
  var PAGE_STATS_KEY = "latestPageStats";
  var MAX_WATER_WORDS_JSON_BYTES = 3e3;
  var DEFAULT_SETTINGS2 = {
    enabled: true,
    isCollapsed: false,
    collapseMode: "placeholder",
    sensitivity: "standard",
    waterWords: [...DEFAULT_WATER_WORDS],
    whitelist: {
      originalPoster: true,
      moderators: true,
      mentions: true,
      quotes: true
    },
    collapsePureMedia: false,
    collapseDuplicates: true,
    shortcutEnabled: true
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function normalizeWords(value) {
    if (!Array.isArray(value)) {
      return [...DEFAULT_SETTINGS2.waterWords];
    }
    const encoder = new TextEncoder();
    const seen = /* @__PURE__ */ new Set();
    const words = [];
    let usedBytes = 2;
    for (const entry of value) {
      if (typeof entry !== "string") {
        continue;
      }
      const word = entry.trim().slice(0, 64);
      if (!word || seen.has(word)) {
        continue;
      }
      const bytes = encoder.encode(JSON.stringify(word)).byteLength + (words.length === 0 ? 0 : 1);
      if (usedBytes + bytes > MAX_WATER_WORDS_JSON_BYTES) {
        break;
      }
      seen.add(word);
      words.push(word);
      usedBytes += bytes;
      if (words.length >= 500) {
        break;
      }
    }
    return words;
  }
  function mergeSettings(value) {
    if (!isRecord(value)) {
      return structuredClone(DEFAULT_SETTINGS2);
    }
    const whitelist = isRecord(value.whitelist) ? value.whitelist : {};
    const sensitivity = value.sensitivity;
    const collapseMode = value.collapseMode;
    return {
      enabled: typeof value.enabled === "boolean" ? value.enabled : DEFAULT_SETTINGS2.enabled,
      isCollapsed: typeof value.isCollapsed === "boolean" ? value.isCollapsed : DEFAULT_SETTINGS2.isCollapsed,
      collapseMode: collapseMode === "placeholder" || collapseMode === "hidden" ? collapseMode : DEFAULT_SETTINGS2.collapseMode,
      sensitivity: sensitivity === "strict" || sensitivity === "standard" || sensitivity === "loose" ? sensitivity : DEFAULT_SETTINGS2.sensitivity,
      waterWords: normalizeWords(value.waterWords),
      whitelist: {
        originalPoster: typeof whitelist.originalPoster === "boolean" ? whitelist.originalPoster : DEFAULT_SETTINGS2.whitelist.originalPoster,
        moderators: typeof whitelist.moderators === "boolean" ? whitelist.moderators : DEFAULT_SETTINGS2.whitelist.moderators,
        mentions: typeof whitelist.mentions === "boolean" ? whitelist.mentions : DEFAULT_SETTINGS2.whitelist.mentions,
        quotes: typeof whitelist.quotes === "boolean" ? whitelist.quotes : DEFAULT_SETTINGS2.whitelist.quotes
      },
      collapsePureMedia: typeof value.collapsePureMedia === "boolean" ? value.collapsePureMedia : DEFAULT_SETTINGS2.collapsePureMedia,
      collapseDuplicates: typeof value.collapseDuplicates === "boolean" ? value.collapseDuplicates : DEFAULT_SETTINGS2.collapseDuplicates,
      shortcutEnabled: typeof value.shortcutEnabled === "boolean" ? value.shortcutEnabled : DEFAULT_SETTINGS2.shortcutEnabled
    };
  }
  function readArea(area, key) {
    return new Promise((resolve, reject) => {
      area.get(key, (items) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(items[key]);
      });
    });
  }
  function writeArea(area, values) {
    return new Promise((resolve, reject) => {
      area.set(values, () => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }
  async function getSettings() {
    const stored = await readArea(chrome.storage.sync, SETTINGS_KEY);
    const merged = mergeSettings(stored);
    if (isRecord(stored) && ("collapseCustomComments" in stored || "customMatchMode" in stored || "customCommentRules" in stored)) {
      await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: merged });
    }
    return merged;
  }
  async function saveSettings(settings2) {
    await writeArea(chrome.storage.sync, { [SETTINGS_KEY]: mergeSettings(settings2) });
  }
  async function savePageStats(stats) {
    await writeArea(chrome.storage.local, { [PAGE_STATS_KEY]: stats });
  }
  function watchSettings(listener) {
    const handleChange = (changes, areaName) => {
      if (areaName !== "sync" || !changes[SETTINGS_KEY]) {
        return;
      }
      listener(mergeSettings(changes[SETTINGS_KEY].newValue));
    };
    chrome.storage.onChanged.addListener(handleChange);
    return () => chrome.storage.onChanged.removeListener(handleChange);
  }

  // src/common/messages.ts
  var APPLY_TRANSIENT_CUSTOM_RULES = "cc98wc:apply-transient-custom-rules";
  var CLEAR_TRANSIENT_CUSTOM_RULES = "cc98wc:clear-transient-custom-rules";
  var EXPAND_ALL_REPLIES = "cc98wc:expand-all-replies";
  var GET_TRANSIENT_CUSTOM_STATE = "cc98wc:get-transient-custom-state";
  var MAX_RAW_INPUT_LENGTH = 20100;
  function isRecord2(value) {
    return typeof value === "object" && value !== null;
  }
  function parseContentMessage(value) {
    if (!isRecord2(value) || typeof value.type !== "string") {
      return null;
    }
    if (value.type === CLEAR_TRANSIENT_CUSTOM_RULES || value.type === EXPAND_ALL_REPLIES || value.type === GET_TRANSIENT_CUSTOM_STATE) {
      return { type: value.type };
    }
    if (value.type !== APPLY_TRANSIENT_CUSTOM_RULES || value.mode !== "exact" && value.mode !== "contains" || typeof value.rawInput !== "string" || value.rawInput.length > MAX_RAW_INPUT_LENGTH) {
      return null;
    }
    return {
      type: APPLY_TRANSIENT_CUSTOM_RULES,
      rawInput: value.rawInput,
      mode: value.mode
    };
  }

  // src/common/topic.ts
  function getCc98TopicKey(value) {
    let url;
    try {
      url = value instanceof URL ? value : new URL(value, "https://www.cc98.org/");
    } catch {
      return null;
    }
    if (url.origin !== "https://www.cc98.org") {
      return null;
    }
    const match = /^\/topic\/([^/]+)(?:\/\d+)?\/?$/u.exec(url.pathname);
    if (!match?.[1]) {
      return null;
    }
    try {
      return decodeURIComponent(match[1]);
    } catch {
      return match[1];
    }
  }
  function canReadTransientState(topicKey) {
    return topicKey !== null;
  }

  // src/content/collapse.ts
  var originalHidden = /* @__PURE__ */ new WeakMap();
  function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return rect.bottom > 0 && rect.top < window.innerHeight;
  }
  function shouldCollapse(reason, options) {
    if (reason === null) {
      return false;
    }
    return reason === "custom" ? options.collapseCustom : options.collapseGlobal;
  }
  function selectStableAnchor(replies, options) {
    const candidate = replies.find(({ element, collapseReason }) => {
      if (!shouldCollapse(collapseReason, options) || options.mode === "placeholder") {
        return isInViewport(element);
      }
      return element.getBoundingClientRect().bottom > 0 && (collapseReason === null || element.dataset.cc98wcManualExpanded === "1");
    });
    const maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    return {
      element: candidate?.element ?? null,
      top: candidate?.element.getBoundingClientRect().top ?? 0,
      scrollRatio: maxScroll > 0 ? window.scrollY / maxScroll : 0
    };
  }
  function removePlaceholder(item) {
    item.querySelector(':scope > [data-cc98wc-placeholder="1"]')?.remove();
  }
  function restoreReply(item) {
    const hiddenBySiteWhilePlaceholder = item.hidden && item.classList.contains("cc98wc-reply-collapsed");
    item.classList.remove("cc98wc-reply-collapsed");
    removePlaceholder(item);
    const wasHidden = originalHidden.get(item);
    if (wasHidden !== void 0) {
      item.hidden = hiddenBySiteWhilePlaceholder || wasHidden;
      originalHidden.delete(item);
    }
    delete item.dataset.cc98wcCollapsed;
    delete item.dataset.cc98wcReason;
  }
  function expandOne(item, onSingleExpand) {
    restoreReply(item);
    item.dataset.cc98wcManualExpanded = "1";
    onSingleExpand();
  }
  function createPlaceholder(item, reason, theme2, onSingleExpand) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "cc98wc-placeholder";
    button.dataset.cc98wc = "1";
    button.dataset.cc98wcPlaceholder = "1";
    updatePlaceholder(button, reason);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      expandOne(item, onSingleExpand);
    });
    theme2.apply(button);
    return button;
  }
  function updatePlaceholder(button, reason) {
    const label = reason === "duplicate" ? "\u76F8\u540C\u8BC4\u8BBA" : reason === "custom" ? "\u81EA\u5B9A\u4E49\u8BC4\u8BBA" : "\u704C\u6C34\u56DE\u590D";
    button.textContent = `\u5DF2\u6298\u53E0 1 \u6761${label} \xB7 \u70B9\u51FB\u5C55\u5F00`;
    button.setAttribute("aria-label", `\u5C55\u5F00\u8FD9\u4E00\u6761\u5DF2\u6298\u53E0\u7684${label}`);
  }
  function collapseReply(item, reason, mode, theme2, onSingleExpand) {
    if (!originalHidden.has(item)) {
      if (item.hidden) {
        return false;
      }
      originalHidden.set(item, item.hidden);
    }
    if (mode === "hidden") {
      item.dataset.cc98wcCollapsed = "1";
      item.dataset.cc98wcReason = reason;
      item.classList.remove("cc98wc-reply-collapsed");
      removePlaceholder(item);
      item.hidden = true;
      return true;
    }
    if (item.hidden) {
      if (item.classList.contains("cc98wc-reply-collapsed")) {
        originalHidden.set(item, true);
        return false;
      }
      item.hidden = originalHidden.get(item) ?? false;
    }
    item.dataset.cc98wcCollapsed = "1";
    item.dataset.cc98wcReason = reason;
    item.classList.add("cc98wc-reply-collapsed");
    const existing = item.querySelector(
      ':scope > [data-cc98wc-placeholder="1"]'
    );
    if (existing) {
      updatePlaceholder(existing, reason);
    } else {
      item.prepend(createPlaceholder(item, reason, theme2, onSingleExpand));
    }
    return true;
  }
  function applyCollapseState(replies, options) {
    const anchor = selectStableAnchor(replies, options);
    let waterCount = 0;
    let customCount = 0;
    let duplicateCount = 0;
    let collapsedCount = 0;
    for (const { element, isWater, isCustom, isDuplicate, collapseReason } of replies) {
      if (options.resetManualExpansions) {
        delete element.dataset.cc98wcManualExpanded;
      }
      element.dataset.cc98wcWater = isWater ? "1" : "0";
      element.dataset.cc98wcCustom = isCustom ? "1" : "0";
      element.dataset.cc98wcDuplicate = isDuplicate ? "1" : "0";
      if (isWater) {
        waterCount += 1;
      }
      if (isCustom) {
        customCount += 1;
      }
      if (isDuplicate) {
        duplicateCount += 1;
      }
      if (collapseReason === null || !shouldCollapse(collapseReason, options)) {
        restoreReply(element);
        delete element.dataset.cc98wcManualExpanded;
        continue;
      }
      if (element.dataset.cc98wcManualExpanded === "1") {
        restoreReply(element);
        continue;
      }
      if (collapseReply(
        element,
        collapseReason,
        options.mode,
        options.theme,
        options.onSingleExpand
      )) {
        collapsedCount += 1;
      }
    }
    if (anchor.element?.isConnected) {
      const delta = anchor.element.getBoundingClientRect().top - anchor.top;
      if (Number.isFinite(delta) && Math.abs(delta) > 0.5) {
        window.scrollBy(0, delta);
      }
    } else if ((options.collapseGlobal || options.collapseCustom) && options.mode === "hidden") {
      const nextMaxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      window.scrollTo(0, anchor.scrollRatio * nextMaxScroll);
    }
    return {
      detectedCount: replies.length,
      waterCount,
      customCount,
      duplicateCount,
      collapsedCount
    };
  }
  function restoreManagedReplies(items) {
    for (const item of items) {
      restoreReply(item);
      delete item.dataset.cc98wcWater;
      delete item.dataset.cc98wcCustom;
      delete item.dataset.cc98wcDuplicate;
      delete item.dataset.cc98wcReason;
      delete item.dataset.cc98wcManualExpanded;
    }
  }

  // src/content/observer.ts
  function elementForNode(node) {
    if (node instanceof Element) {
      return node;
    }
    return node.parentElement;
  }
  function isOwnedNode(node) {
    const element = elementForNode(node);
    return Boolean(element?.matches('[data-cc98wc="1"]') || element?.closest('[data-cc98wc="1"]'));
  }
  function isExtensionOnlyMutation(mutation) {
    if (isOwnedNode(mutation.target)) {
      return true;
    }
    const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes];
    return changedNodes.length > 0 && changedNodes.every(isOwnedNode);
  }
  function observeReplyContainer(container, onChange, onDetached, debounceMs = 200) {
    let timeoutId;
    let stopped = false;
    const schedule = () => {
      if (stopped) {
        return;
      }
      if (timeoutId !== void 0) {
        window.clearTimeout(timeoutId);
      }
      timeoutId = window.setTimeout(() => {
        timeoutId = void 0;
        onChange();
      }, Math.max(150, debounceMs));
    };
    const observer = new MutationObserver((mutations) => {
      if (mutations.every(isExtensionOnlyMutation)) {
        return;
      }
      schedule();
    });
    observer.observe(container, {
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "id",
        "data-floor",
        "data-reply-id",
        "data-testid",
        "data-role",
        // 懒加载完成或站点切换条目可见性后，需要重新生成重复指纹。
        "src",
        "data-src",
        "data-original",
        "hidden"
      ],
      subtree: true
    });
    const connectionTimer = window.setInterval(() => {
      if (container.isConnected) {
        return;
      }
      observer.disconnect();
      window.clearInterval(connectionTimer);
      stopped = true;
      onDetached();
    }, 2e3);
    return {
      schedule,
      disconnect: () => {
        stopped = true;
        observer.disconnect();
        window.clearInterval(connectionTimer);
        if (timeoutId !== void 0) {
          window.clearTimeout(timeoutId);
        }
      }
    };
  }

  // src/content/selectors.ts
  var CONTAINER_SELECTORS = [
    '[data-testid="reply-list"]',
    '[data-testid="comment-list"]',
    '[data-role="reply-list"]',
    '[data-role="comment-list"]',
    '[role="feed"]',
    '[aria-label="\u56DE\u590D\u5217\u8868"]',
    '[aria-label="\u8BC4\u8BBA\u5217\u8868"]'
  ];
  var ITEM_SELECTORS = [
    // 实站校准（2026-09 侦察报告）：CC98 经典前端的回复卡片是 div.reply。
    "div.reply",
    '[data-testid="reply-item"]',
    '[data-testid="comment-item"]',
    '[data-role="reply-item"]',
    '[data-role="comment-item"]',
    "article[data-floor]",
    "article[data-reply-id]",
    'article[id^="post-"]',
    '[role="article"][data-floor]'
  ];
  var CONTENT_SELECTORS = [
    '[data-testid="reply-body"]',
    '[data-testid="comment-content"]',
    '[data-testid="reply-content"]',
    '[data-role="reply-body"]',
    '[data-role="content"]',
    '[itemprop="text"]',
    ".markdown-body",
    // 实站校准：CC98 回复正文容器；签名档 .signature 在其外，天然被排除。
    ".substance"
  ];
  var IDENTITY_SELECTORS = [
    "header img",
    '[data-testid*="avatar" i]',
    '[data-role*="avatar" i]',
    '[aria-label*="\u5934\u50CF"]',
    "[data-author]",
    "[data-username]",
    'a[href^="/user/"]',
    // 实站校准：CC98 用绝对链接（/user/id/…）与 .userPortrait 头像。
    'a[href*="/user/id/"]',
    ".userPortrait",
    ".userMessage-userName"
  ];
  var QUOTE_SELECTORS = [
    "blockquote",
    '[data-testid="quote"]',
    '[data-role="quote"]',
    '[aria-label="\u5F15\u7528"]'
  ];
  var MENTION_SELECTORS = [
    '[data-testid="mention"]',
    '[data-role="mention"]',
    'a[href^="/user/"]',
    'a[href*="/user/id/"]'
  ];
  var ORIGINAL_POSTER_SELECTORS = [
    '[data-is-op="true"]',
    '[data-author-role="owner"]',
    '[data-testid="op-badge"]',
    '[aria-label="\u697C\u4E3B"]'
  ];
  var MODERATOR_SELECTORS = [
    '[data-is-moderator="true"]',
    '[data-author-role="moderator"]',
    '[data-testid="moderator-badge"]',
    '[aria-label="\u7248\u4E3B"]'
  ];
  var NON_CONTENT_SELECTORS = [
    '[data-testid="reply-actions"]',
    '[data-role="reply-actions"]',
    '[data-testid="reply-meta"]',
    '[data-role="reply-meta"]'
  ];
  var PRUNE_FROM_TEXT_SELECTORS = [
    ...QUOTE_SELECTORS,
    ...MENTION_SELECTORS,
    "pre",
    "code",
    "script",
    "style",
    "noscript",
    '[data-cc98wc="1"]',
    '[aria-hidden="true"]',
    ...NON_CONTENT_SELECTORS
  ];
  var DUPLICATE_EXCLUDED_SELECTORS = [
    ".signature",
    '[data-cc98wc="1"]',
    '[aria-hidden="true"]',
    "script",
    "style",
    "noscript",
    ...NON_CONTENT_SELECTORS
  ];
  var UNSUPPORTED_DUPLICATE_MEDIA_SELECTOR = "video, audio, svg, canvas, iframe, object, embed";
  var MENTION_TEXT_PATTERN = /@[^\s@，。！？,.!?]{1,32}/gu;
  function selectAll(root, selectors) {
    const matches = selectors.flatMap(
      (selector) => Array.from(root.querySelectorAll(selector))
    );
    return [...new Set(matches)];
  }
  function selectFirst(root, selectors) {
    for (const selector of selectors) {
      const match = root.querySelector(selector);
      if (match) {
        return match;
      }
    }
    return null;
  }
  function topLevelOnly(items) {
    const set = new Set(items);
    return items.filter((item) => {
      let ancestor = item.parentElement;
      while (ancestor) {
        if (set.has(ancestor)) {
          return false;
        }
        ancestor = ancestor.parentElement;
      }
      return true;
    });
  }
  function findLowestCommonAncestor(elements) {
    const first = elements[0];
    if (!first) {
      return null;
    }
    let candidate = first.parentElement;
    while (candidate && candidate !== document.body && candidate !== document.documentElement) {
      if (elements.every((element) => candidate?.contains(element))) {
        return candidate;
      }
      candidate = candidate.parentElement;
    }
    return null;
  }
  function hasFloorSignal(element) {
    return Boolean(
      element.matches('[data-floor], [aria-label*="\u697C"], [id^="post-"]') || element.querySelector(
        // .reply-floor 是实站校准出的 CC98 楼层标记（页面没有 <time>）。
        '[data-floor], .reply-floor, a[href^="#post-"], a[href*="floor"]'
      )
    );
  }
  function isLikelyReplyArticle(element) {
    const hasTimeOrFloor = hasFloorSignal(element) || Boolean(element.querySelector("time"));
    const hasBody = Boolean(
      selectFirst(element, CONTENT_SELECTORS) ?? element.querySelector("p, picture, video")
    );
    const hasIdentity = element.matches(IDENTITY_SELECTORS.join(",")) || Boolean(selectFirst(element, IDENTITY_SELECTORS));
    return hasTimeOrFloor && hasBody && hasIdentity;
  }
  function getReplyItems(container) {
    const semantic = topLevelOnly(selectAll(container, ITEM_SELECTORS)).filter(isLikelyReplyArticle);
    if (semantic.length > 0) {
      return semantic;
    }
    return Array.from(container.querySelectorAll("article")).filter(isLikelyReplyArticle);
  }
  function findReplyContext(root = document) {
    for (const selector of CONTAINER_SELECTORS) {
      const containers = root.querySelectorAll(selector);
      for (const container of containers) {
        const items = getReplyItems(container);
        const requiresFloorSignal = selector === '[role="feed"]';
        if (items.length > 0 && (!requiresFloorSignal || items.some(hasFloorSignal))) {
          return { container, items };
        }
      }
    }
    const semanticItems = topLevelOnly(selectAll(root, ITEM_SELECTORS)).filter(isLikelyReplyArticle);
    if (semanticItems.length > 0 && semanticItems.some(hasFloorSignal)) {
      const container = findLowestCommonAncestor(semanticItems);
      if (container) {
        return { container, items: semanticItems.filter((item) => container.contains(item)) };
      }
    }
    const articles = Array.from(root.querySelectorAll('main article, [role="main"] article')).filter(isLikelyReplyArticle);
    if (articles.length >= 2 && articles.some(hasFloorSignal)) {
      const container = findLowestCommonAncestor(articles);
      if (container) {
        return { container, items: articles.filter((item) => container.contains(item)) };
      }
    }
    return null;
  }
  var BADGE_CANDIDATE_SELECTORS = [
    '[role="status"]',
    '[data-role="badge"]',
    '[data-testid$="badge"]',
    "[aria-label]",
    "span",
    "em",
    "i",
    "b",
    "strong",
    "small",
    "sup",
    "a",
    "div",
    "label"
  ];
  var BADGE_EXCLUDED_SELECTORS = [".reply-content", ".substance", ".signature"];
  function hasExactBadge(item, label) {
    const candidates = item.querySelectorAll(BADGE_CANDIDATE_SELECTORS.join(","));
    return Array.from(candidates).some((candidate) => {
      if (candidate.closest(BADGE_EXCLUDED_SELECTORS.join(","))) {
        return false;
      }
      const ariaLabel = candidate.getAttribute("aria-label")?.trim();
      if (ariaLabel === label) {
        return true;
      }
      if (candidate.textContent?.trim() !== label) {
        return false;
      }
      return !candidate.querySelector("a, button, img, article, input, textarea");
    });
  }
  function textWithoutExcludedNodes(source) {
    const clone = source.cloneNode(true);
    for (const selector of PRUNE_FROM_TEXT_SELECTORS) {
      clone.querySelectorAll(selector).forEach((node) => node.remove());
    }
    return (clone.textContent ?? "").replace(MENTION_TEXT_PATTERN, "").trim();
  }
  function exactTextWithoutMetadata(source) {
    const clone = source.cloneNode(true);
    for (const selector of DUPLICATE_EXCLUDED_SELECTORS) {
      if (clone.matches(selector)) {
        return "";
      }
      clone.querySelectorAll(selector).forEach((node) => node.remove());
    }
    return clone.textContent ?? "";
  }
  function isDuplicateExcluded(node) {
    return Boolean(node.closest(DUPLICATE_EXCLUDED_SELECTORS.join(",")));
  }
  function hasIncludedNode(scopes, selector) {
    return scopes.some(
      (scope) => Array.from(scope.querySelectorAll(selector)).some((node) => !isDuplicateExcluded(node))
    );
  }
  function stableImageSource(image) {
    const rawSource = [
      image.getAttribute("data-original"),
      image.getAttribute("data-src"),
      image.getAttribute("src")
    ].find((source) => Boolean(source?.trim()));
    if (!rawSource) {
      return "";
    }
    try {
      const url = new URL(rawSource, document.baseURI);
      url.hash = "";
      return url.href;
    } catch {
      return "";
    }
  }
  function createContentView(item) {
    const semantic = selectFirst(item, CONTENT_SELECTORS);
    if (semantic) {
      return {
        scopes: [semantic],
        text: textWithoutExcludedNodes(semantic),
        originalText: semantic.textContent?.trim() ?? ""
      };
    }
    const paragraphs = Array.from(item.querySelectorAll("p")).filter(
      (paragraph) => !paragraph.closest(QUOTE_SELECTORS.join(",")) && !paragraph.closest(NON_CONTENT_SELECTORS.join(","))
    );
    if (paragraphs.length > 0) {
      return {
        scopes: paragraphs,
        text: paragraphs.map(textWithoutExcludedNodes).filter(Boolean).join("\n"),
        originalText: paragraphs.map((paragraph) => paragraph.textContent?.trim() ?? "").join("\n")
      };
    }
    return {
      scopes: [item],
      text: textWithoutExcludedNodes(item),
      originalText: item.textContent?.trim() ?? ""
    };
  }
  function extractDetectionInput(item) {
    const content = createContentView(item);
    const inContentScopes = (predicate) => content.scopes.some(predicate);
    const hasMentionElement = inContentScopes((scope) => Boolean(selectFirst(scope, MENTION_SELECTORS)));
    const hasMentionText = /@[^\s@，。！？,.!?]{1,32}/u.test(content.originalText);
    return {
      text: content.text,
      isOriginalPoster: item.matches(ORIGINAL_POSTER_SELECTORS.join(",")) || Boolean(selectFirst(item, ORIGINAL_POSTER_SELECTORS)) || hasExactBadge(item, "\u697C\u4E3B"),
      isModerator: item.matches(MODERATOR_SELECTORS.join(",")) || Boolean(selectFirst(item, MODERATOR_SELECTORS)) || hasExactBadge(item, "\u7248\u4E3B"),
      // 引用和代码是硬保护；从整个回复检查可避免未知 DOM 中同级节点被漏掉。
      hasQuote: Boolean(selectFirst(item, QUOTE_SELECTORS)),
      hasMention: hasMentionElement || hasMentionText,
      hasCode: Boolean(item.querySelector("pre, code")),
      hasLink: inContentScopes((scope) => Boolean(scope.querySelector("a[href]"))),
      hasMedia: inContentScopes((scope) => Boolean(scope.querySelector("img, picture, video, svg")))
    };
  }
  function extractDuplicateCandidate(item) {
    const content = createContentView(item);
    const images = content.scopes.flatMap(
      (scope) => Array.from(scope.querySelectorAll("img")).filter((image) => !isDuplicateExcluded(image)).map(stableImageSource)
    );
    return {
      text: content.scopes.map(exactTextWithoutMetadata).join("\n"),
      imageSources: images,
      hasQuote: hasIncludedNode(content.scopes, QUOTE_SELECTORS.join(",")),
      hasCode: hasIncludedNode(content.scopes, "pre, code"),
      hasLink: hasIncludedNode(content.scopes, "a[href]"),
      hasUnsupportedMedia: hasIncludedNode(
        content.scopes,
        UNSUPPORTED_DUPLICATE_MEDIA_SELECTOR
      )
    };
  }
  function containsReplyItem(container, target) {
    return getReplyItems(container).find((item) => item === target || item.contains(target)) ?? null;
  }

  // src/content/theme.ts
  var DARK_MARKERS = /(?:^|[-_\s])(dark|night|dim|black|nighttime)(?:$|[-_\s])|暗色|夜间/iu;
  var LIGHT_MARKERS = /(?:^|[-_\s])(light|day|bright|daytime)(?:$|[-_\s])|亮色|日间/iu;
  var PRIMARY_VARIABLES = [
    "--primary",
    "--color-primary",
    "--primary-color",
    "--theme-primary",
    "--accent",
    "--color-accent"
  ];
  function resolveThemeMode(signals) {
    for (const declared of [signals.dataTheme, signals.dataColorScheme]) {
      if (!declared) continue;
      if (DARK_MARKERS.test(declared.toLowerCase())) return "dark";
      if (LIGHT_MARKERS.test(declared.toLowerCase())) return "light";
    }
    const classNames = [signals.htmlClass, signals.bodyClass].filter((value) => Boolean(value)).join(" ").toLowerCase();
    if (DARK_MARKERS.test(classNames)) {
      return "dark";
    }
    if (LIGHT_MARKERS.test(classNames)) {
      return "light";
    }
    return signals.prefersDark ? "dark" : "light";
  }
  function readPrimaryColor() {
    const nodes = [document.documentElement, document.body].filter(
      (node) => Boolean(node)
    );
    for (const node of nodes) {
      const styles = getComputedStyle(node);
      for (const variable of PRIMARY_VARIABLES) {
        const candidate = styles.getPropertyValue(variable).trim();
        if (candidate && candidate !== "transparent" && !candidate.startsWith("var(") && CSS.supports("color", candidate)) {
          return candidate;
        }
      }
    }
    return null;
  }
  function readThemeSnapshot() {
    const media = matchMedia("(prefers-color-scheme: dark)");
    const html = document.documentElement;
    const body = document.body;
    const mode = resolveThemeMode({
      htmlClass: html.className,
      bodyClass: body?.className ?? "",
      dataTheme: html.dataset.theme ?? body?.dataset.theme ?? "",
      dataColorScheme: html.dataset.colorScheme ?? body?.dataset.colorScheme ?? html.getAttribute("color-scheme") ?? "",
      prefersDark: media.matches
    });
    const accent = readPrimaryColor() ?? (mode === "dark" ? "#93c5fd" : "#2563eb");
    if (mode === "dark") {
      return {
        mode,
        accent,
        surface: "#1f2937",
        surfaceHover: "#273449",
        text: "#f9fafb",
        mutedText: "#d1d5db",
        border: "#4b5563",
        shadow: "0 8px 24px rgb(0 0 0 / 38%)"
      };
    }
    return {
      mode,
      accent,
      surface: "#ffffff",
      surfaceHover: "#f3f4f6",
      text: "#111827",
      mutedText: "#4b5563",
      border: "#d1d5db",
      shadow: "0 8px 24px rgb(15 23 42 / 18%)"
    };
  }
  function applySnapshot(element, snapshot) {
    element.dataset.cc98wcTheme = snapshot.mode;
    element.style.setProperty("--cc98wc-accent", snapshot.accent);
    element.style.setProperty("--cc98wc-surface", snapshot.surface);
    element.style.setProperty("--cc98wc-surface-hover", snapshot.surfaceHover);
    element.style.setProperty("--cc98wc-text", snapshot.text);
    element.style.setProperty("--cc98wc-muted-text", snapshot.mutedText);
    element.style.setProperty("--cc98wc-border", snapshot.border);
    element.style.setProperty("--cc98wc-shadow", snapshot.shadow);
  }
  function createThemeController() {
    let snapshot = readThemeSnapshot();
    let refreshQueued = false;
    const apply = (element) => applySnapshot(element, snapshot);
    const refresh = () => {
      snapshot = readThemeSnapshot();
      document.querySelectorAll('[data-cc98wc="1"]').forEach(apply);
    };
    const queueRefresh = () => {
      if (refreshQueued) {
        return;
      }
      refreshQueued = true;
      queueMicrotask(() => {
        refreshQueued = false;
        refresh();
      });
    };
    const htmlObserver = new MutationObserver(queueRefresh);
    htmlObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "data-theme", "data-color-scheme", "color-scheme", "style"]
    });
    const bodyObserver = new MutationObserver(queueRefresh);
    if (document.body) {
      bodyObserver.observe(document.body, {
        attributes: true,
        attributeFilter: ["class", "data-theme", "data-color-scheme", "color-scheme", "style"]
      });
    }
    const media = matchMedia("(prefers-color-scheme: dark)");
    media.addEventListener("change", queueRefresh);
    return {
      apply,
      refresh,
      disconnect: () => {
        htmlObserver.disconnect();
        bodyObserver.disconnect();
        media.removeEventListener("change", queueRefresh);
      }
    };
  }

  // src/content/ui-button.ts
  function createIcon() {
    const namespace = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(namespace, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "18");
    svg.setAttribute("height", "18");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    const path = document.createElementNS(namespace, "path");
    path.setAttribute("d", "M5 7h14M7 12h10M9 17h6");
    path.setAttribute("fill", "none");
    path.setAttribute("stroke", "currentColor");
    path.setAttribute("stroke-width", "2");
    path.setAttribute("stroke-linecap", "round");
    svg.append(path);
    return svg;
  }
  function createPageButton(theme2, onToggle) {
    const root = document.createElement("div");
    root.className = "cc98wc-floating";
    root.dataset.cc98wc = "1";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "cc98wc-toggle";
    button.addEventListener("click", onToggle);
    const label = document.createElement("span");
    label.className = "cc98wc-toggle__label";
    const count = document.createElement("span");
    count.className = "cc98wc-toggle__count";
    count.setAttribute("aria-live", "polite");
    button.append(createIcon(), label, count);
    root.append(button);
    document.body.append(root);
    theme2.apply(root);
    return {
      element: root,
      update: (state) => {
        label.textContent = state.collapsed ? "\u663E\u793A\u5168\u90E8\u56DE\u590D" : "\u4E00\u952E\u6298\u53E0";
        count.textContent = state.collapsed ? `\u5DF2\u6298\u53E0 ${state.collapsedCount} \u6761` : `\u6C34\u5E16 ${state.waterCount} \xB7 \u81EA\u5B9A\u4E49 ${state.customCount} \xB7 \u76F8\u540C ${state.duplicateCount}`;
        button.setAttribute("aria-pressed", String(state.collapsed));
        button.setAttribute(
          "aria-label",
          state.collapsed ? `\u663E\u793A\u5168\u90E8\u56DE\u590D\uFF0C\u5F53\u524D\u5DF2\u6298\u53E0 ${state.collapsedCount} \u6761` : `\u4E00\u952E\u6298\u53E0\uFF0C\u5F53\u524D\u68C0\u6D4B\u5230 ${state.waterCount} \u6761\u6C34\u5E16\u3001${state.customCount} \u6761\u81EA\u5B9A\u4E49\u8BC4\u8BBA\u3001${state.duplicateCount} \u6761\u76F8\u540C\u8BC4\u8BBA`
        );
      },
      destroy: () => root.remove()
    };
  }

  // src/content/index.ts
  var LOG_PREFIX = "[CC98 \u6C34\u5E16\u6298\u53E0\u5668]";
  var pageId = crypto.randomUUID();
  var discoveryDelays = [0, 300, 1e3, 2500, 5e3, 1e4, 2e4, 3e4];
  var settings;
  var context = null;
  var replyObserver = null;
  var pageButton = null;
  var discoveryTimers = [];
  var warnedMissingContainer = false;
  var lastStatsSignature = "";
  var lastSeenRoute = `${location.pathname}${location.search}`;
  var currentTopicKey = getCc98TopicKey(location.href);
  var transientCustomInput = "";
  var transientCustomRules = [];
  var transientCustomMode = "exact";
  var theme = createThemeController();
  function clearTransientCustomState() {
    transientCustomInput = "";
    transientCustomRules = [];
    transientCustomMode = "exact";
  }
  function clearDiscoveryTimers() {
    for (const timer of discoveryTimers) {
      window.clearTimeout(timer);
    }
    discoveryTimers = [];
  }
  function currentItems() {
    return context ? getReplyItems(context.container) : [];
  }
  function publishStats(result, force = false) {
    const isAnyCollapseActive = settings.isCollapsed || transientCustomRules.length > 0;
    const signature = [
      result.detectedCount,
      result.waterCount,
      result.customCount,
      result.duplicateCount,
      result.collapsedCount,
      isAnyCollapseActive
    ].join(":");
    if (!force && signature === lastStatsSignature) {
      return;
    }
    lastStatsSignature = signature;
    const stats = {
      pageId,
      detectedCount: result.detectedCount,
      waterCount: result.waterCount,
      customCount: result.customCount,
      duplicateCount: result.duplicateCount,
      collapsedCount: result.collapsedCount,
      isCollapsed: isAnyCollapseActive,
      updatedAt: Date.now()
    };
    void savePageStats(stats).catch((error) => {
      console.warn(`${LOG_PREFIX} \u65E0\u6CD5\u4FDD\u5B58\u672C\u9875\u7EDF\u8BA1\u3002`, error);
    });
  }
  function classifyReplies(items) {
    const hiddenBySite = items.map(
      (element) => element.hidden && (element.dataset.cc98wcCollapsed !== "1" || element.classList.contains("cc98wc-reply-collapsed"))
    );
    const detectionInputs = items.map(
      (element, index) => hiddenBySite[index] ? null : extractDetectionInput(element)
    );
    const detections = detectionInputs.map(
      (input) => input === null ? null : detectWaterReply(input, settings)
    );
    const duplicateCandidates = items.map(
      (element, index) => hiddenBySite[index] ? null : extractDuplicateCandidate(element)
    );
    const protectedReplies = detections.map((detection) => detection?.reason === "whitelisted");
    const customMatches = detectionInputs.map((input, index) => {
      const detection = detections[index];
      const candidate = duplicateCandidates[index];
      return Boolean(
        transientCustomRules.length > 0 && input && candidate && detection && !protectedReplies[index] && matchesCustomComment(
          // 灌水检测文本会剔除引用和 @；自定义规则必须匹配保留这些内容的完整正文。
          candidate.text,
          transientCustomRules,
          transientCustomMode
        )
      );
    });
    const fingerprints = duplicateCandidates.map(
      (candidate) => candidate === null ? null : createDuplicateFingerprint(candidate)
    );
    const priorities = detections.map(
      (detection, index) => resolveReplyPriority({
        protected: protectedReplies[index] ?? false,
        customMatch: customMatches[index] ?? false,
        waterMatch: detection?.isWater ?? false
      })
    );
    const duplicates = classifyDuplicateFingerprints(
      fingerprints,
      settings.collapseDuplicates,
      detections.map(
        (detection, index) => detection === null || priorities[index] !== "content"
      )
    );
    return items.map((element, index) => {
      const priority = priorities[index] ?? "content";
      const isCustom = priority === "custom";
      const isWater = priority === "water";
      const duplicate = duplicates[index] ?? { isDuplicate: false, shouldCollapse: false };
      return {
        element,
        isWater,
        isCustom,
        isDuplicate: duplicate.isDuplicate,
        collapseReason: isWater ? "water" : isCustom ? "custom" : duplicate.shouldCollapse ? "duplicate" : null
      };
    });
  }
  function scanReplies(resetManualExpansions = false) {
    if (!context || !settings.enabled) {
      return null;
    }
    const items = currentItems();
    if (items.length === 0) {
      unmountContext();
      scheduleDiscovery();
      return null;
    }
    context.items = items;
    const result = applyCollapseState(classifyReplies(items), {
      collapseGlobal: settings.isCollapsed,
      collapseCustom: transientCustomRules.length > 0,
      mode: settings.collapseMode,
      resetManualExpansions,
      theme,
      onSingleExpand: () => window.setTimeout(() => scanReplies(false), 0)
    });
    pageButton?.update({
      collapsed: settings.isCollapsed || transientCustomRules.length > 0,
      waterCount: result.waterCount,
      customCount: result.customCount,
      duplicateCount: result.duplicateCount,
      collapsedCount: result.collapsedCount
    });
    publishStats(result);
    return result;
  }
  async function toggleCollapsed() {
    const previous = settings;
    const previousTransientInput = transientCustomInput;
    const previousTransientRules = transientCustomRules;
    const previousTransientMode = transientCustomMode;
    const wasAnyCollapseActive = settings.isCollapsed || transientCustomRules.length > 0;
    const nextCollapsed = !wasAnyCollapseActive;
    if (wasAnyCollapseActive) {
      clearTransientCustomState();
    }
    settings = { ...settings, isCollapsed: nextCollapsed };
    scanReplies(nextCollapsed);
    try {
      const latest = await getSettings();
      settings = { ...latest, isCollapsed: nextCollapsed };
      await saveSettings(settings);
    } catch (error) {
      settings = previous;
      transientCustomInput = previousTransientInput;
      transientCustomRules = previousTransientRules;
      transientCustomMode = previousTransientMode;
      scanReplies(false);
      console.warn(`${LOG_PREFIX} \u65E0\u6CD5\u4FDD\u5B58\u6298\u53E0\u72B6\u6001\u3002`, error);
    }
  }
  function mountContext(nextContext) {
    if (context?.container === nextContext.container) {
      scanReplies(false);
      return;
    }
    unmountContext();
    context = nextContext;
    warnedMissingContainer = false;
    pageButton = createPageButton(theme, () => {
      void toggleCollapsed();
    });
    replyObserver = observeReplyContainer(
      context.container,
      () => scanReplies(false),
      () => {
        unmountContext();
        scheduleDiscovery();
      }
    );
    scanReplies(false);
    requestAnimationFrame(revealHashTarget);
  }
  function unmountContext() {
    replyObserver?.disconnect();
    replyObserver = null;
    pageButton?.destroy();
    pageButton = null;
    if (context) {
      restoreManagedReplies(getReplyItems(context.container));
    }
    context = null;
  }
  function tryDiscover(isLastAttempt) {
    if (!settings.enabled) {
      return;
    }
    const nextContext = findReplyContext();
    if (nextContext) {
      clearDiscoveryTimers();
      mountContext(nextContext);
      return;
    }
    if (isLastAttempt && !warnedMissingContainer) {
      warnedMissingContainer = true;
      console.warn(`${LOG_PREFIX} \u672A\u8BC6\u522B\u5230\u56DE\u590D\u5BB9\u5668\uFF0C\u5DF2\u505C\u7528\u3002`);
    }
  }
  function scheduleDiscovery() {
    clearDiscoveryTimers();
    if (!settings.enabled) {
      return;
    }
    discoveryDelays.forEach((delay, index) => {
      const timer = window.setTimeout(
        () => tryDiscover(index === discoveryDelays.length - 1),
        delay
      );
      discoveryTimers.push(timer);
    });
  }
  function handleSettingsChange(nextSettings) {
    const wasEnabled = settings.enabled;
    const collapseJustEnabled = !settings.isCollapsed && nextSettings.isCollapsed;
    settings = nextSettings;
    if (!settings.enabled) {
      clearTransientCustomState();
      clearDiscoveryTimers();
      unmountContext();
      publishStats(
        {
          detectedCount: 0,
          waterCount: 0,
          customCount: 0,
          duplicateCount: 0,
          collapsedCount: 0
        },
        true
      );
      return;
    }
    if (!wasEnabled) {
      scheduleDiscovery();
      return;
    }
    if (context) {
      scanReplies(collapseJustEnabled);
    } else {
      scheduleDiscovery();
    }
  }
  function isEditingTarget(target) {
    if (!(target instanceof HTMLElement)) {
      return false;
    }
    return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement || target.isContentEditable || Boolean(target.closest("[contenteditable]"));
  }
  function handleShortcut(event) {
    if (!settings.enabled || !settings.shortcutEnabled || !event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.key.toLowerCase() !== "h" || isEditingTarget(event.target)) {
      return;
    }
    event.preventDefault();
    void toggleCollapsed();
  }
  function revealHashTarget() {
    if (!context || !location.hash) {
      return;
    }
    let id;
    try {
      id = decodeURIComponent(location.hash.slice(1));
    } catch {
      id = location.hash.slice(1);
    }
    const target = document.getElementById(id);
    if (!target) {
      return;
    }
    const item = containsReplyItem(context.container, target);
    if (item?.dataset.cc98wcCollapsed === "1") {
      item.dataset.cc98wcManualExpanded = "1";
      scanReplies(false);
      requestAnimationFrame(() => target.scrollIntoView({ block: "start" }));
    }
  }
  function handlePotentialNavigation(event) {
    if (event) {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      const link = target.closest("a[href]");
      if (!link || link.origin !== location.origin) {
        return;
      }
    }
    window.setTimeout(handleDocumentLocationChange, 150);
  }
  function handleDocumentLocationChange() {
    const nextRoute = `${location.pathname}${location.search}`;
    const nextTopicKey = getCc98TopicKey(location.href);
    if (nextRoute !== lastSeenRoute) {
      lastSeenRoute = nextRoute;
      if (nextTopicKey !== currentTopicKey) {
        clearTransientCustomState();
      }
      currentTopicKey = nextTopicKey;
      lastStatsSignature = "";
    }
    scheduleDiscovery();
  }
  function handleRuntimeMessage(rawMessage, sender, sendResponse) {
    if (sender.id !== chrome.runtime.id) {
      return false;
    }
    const message = parseContentMessage(rawMessage);
    if (!message) {
      sendResponse({ ok: false, error: "invalid-message" });
      return false;
    }
    if (!settings.enabled) {
      sendResponse({ ok: false, error: "disabled" });
      return false;
    }
    if (message.type === GET_TRANSIENT_CUSTOM_STATE) {
      if (!canReadTransientState(currentTopicKey)) {
        sendResponse({ ok: false, error: "no-topic" });
        return false;
      }
      sendResponse({
        ok: true,
        kind: "state",
        rawInput: transientCustomInput,
        mode: transientCustomMode
      });
      return false;
    }
    if (!context) {
      sendResponse({ ok: false, error: "no-topic" });
      return false;
    }
    if (message.type === APPLY_TRANSIENT_CUSTOM_RULES) {
      const rules = normalizeCustomCommentRules(message.rawInput.split(/\r?\n/u));
      if (rules.length === 0) {
        sendResponse({ ok: false, error: "no-valid-rules" });
        return false;
      }
      transientCustomInput = message.rawInput;
      transientCustomRules = rules;
      transientCustomMode = message.mode;
      const result2 = scanReplies(true);
      sendResponse(
        result2 ? {
          ok: true,
          kind: "action",
          customCount: result2.customCount,
          collapsedCount: result2.collapsedCount
        } : { ok: false, error: "no-topic" }
      );
      return false;
    }
    clearTransientCustomState();
    if (message.type === EXPAND_ALL_REPLIES) {
      settings = { ...settings, isCollapsed: false };
      void saveSettings(settings).catch((error) => {
        console.warn(`${LOG_PREFIX} \u65E0\u6CD5\u4FDD\u5B58\u5C55\u5F00\u72B6\u6001\u3002`, error);
      });
    }
    const result = scanReplies(false);
    sendResponse(
      result ? {
        ok: true,
        kind: "action",
        customCount: result.customCount,
        collapsedCount: result.collapsedCount
      } : { ok: false, error: "no-topic" }
    );
    return false;
  }
  async function start() {
    try {
      settings = await getSettings();
    } catch (error) {
      console.warn(`${LOG_PREFIX} \u65E0\u6CD5\u8BFB\u53D6\u8BBE\u7F6E\uFF0C\u6269\u5C55\u672A\u542F\u52A8\u3002`, error);
      return;
    }
    watchSettings(handleSettingsChange);
    chrome.runtime.onMessage.addListener(handleRuntimeMessage);
    document.addEventListener("keydown", handleShortcut, true);
    document.addEventListener("click", handlePotentialNavigation, true);
    window.addEventListener("popstate", () => handlePotentialNavigation());
    window.addEventListener("hashchange", revealHashTarget);
    window.addEventListener("focus", () => {
      if (context) {
        lastStatsSignature = "";
        scanReplies(false);
      }
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden && context) {
        lastStatsSignature = "";
        scanReplies(false);
      }
    });
    window.setInterval(() => {
      const nextRoute = `${location.pathname}${location.search}`;
      if (nextRoute === lastSeenRoute) {
        return;
      }
      handleDocumentLocationChange();
    }, 1e3);
    if (settings.enabled) {
      scheduleDiscovery();
    }
  }
  void start();
})();
